    <?php 
        include("config.php");
        include("header.php");
    ?>    	
    <main>
    		<div id="maincolumn">
                Welcome to your gallery, here you can save your pictures!

                <?php
                    $dirname = "uploadedfiles";
                    $images = glob($dirname."*.{jpg,gif,png}");

                    foreach($images as $image) {
                    echo '<img src="'.$image.'" /><br />';
                }
                    ?>
                <div class="grid">
                    
                </div> 
    		</div>
    	</main>

    </body>